Network Similarity Decomposition (NSD): A Fast and Scalable Approach to Network Alignment

G. Kollias, S. Mohammadi, and A. Grama. (2011). Network Similarity Decomposition (NSD): A Fast and Scalable Approach to Network Alignment. IEEE Transactions on Knowledge and Data Engineering, 24(12), 2232–2243. doi:10.1109/TKDE.2011.174
